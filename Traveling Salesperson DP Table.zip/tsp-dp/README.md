# Traveling Salesperson Problem – DP State Transitions (Held-Karp)

**Unit:** _<fill in>_  |  **Group:** _<fill in>_  |  **Member:** _<fill in>_

## Problem statement
Given 4 cities and a distance matrix, find the shortest tour that starts at city 0, visits every city exactly once and returns to city 0.

## Approach: Held-Karp dynamic programming
`g(S, j)` = cheapest path that starts at 0, visits every city in subset `S` exactly once and ends at `j`.

```
TSP(dist, n):
  for j = 1..n-1:  g[{j}][j] = dist[0][j]
  for size = 2..n-1:
    for each subset S of {1..n-1} with |S| = size:
      for each j in S:
        g[S][j] = min over k in S\{j} of ( g[S\{j}][k] + dist[k][j] )
        parent[S][j] = argmin k
  answer = min over j of ( g[full][j] + dist[j][0] )
  rebuild tour by following parent[][]
```

**Complexity:** O(n²·2ⁿ) time, O(n·2ⁿ) space (vs O(n!) brute force).

## Sample input
| | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| 0 | 0 | 10 | 15 | 20 |
| 1 | 10 | 0 | 35 | 25 |
| 2 | 15 | 35 | 0 | 30 |
| 3 | 20 | 25 | 30 | 0 |

## Output
Optimal cost = **80**. Two tours tie: `0→1→3→2→0` and its reverse `0→2→3→1→0` (the script prints one of them).

## Visualization
### Animation (DP table filled step by step)
![DP animation](docs/dp_animation.gif)

### Static diagram
![DP transitions](docs/dp_transitions.png)

Each column is a subset size. Each node is a state (S, j) with its cost. Arrows are transitions, and each node keeps the cheaper incoming one. The teal path is the optimal tour. The last column adds the return edge to city 0.

**AI prompt used:** see [`docs/prompt.txt`](docs/prompt.txt).

## How to run
```bash
python src/tsp_dp.py          # prints every DP step and the optimal tour
python src/make_diagram.py    # regenerates docs/dp_transitions.png (needs matplotlib)
python src/make_animation.py  # regenerates docs/dp_animation.gif (needs matplotlib + pillow)
```

## Repository structure
```
tsp-dp/
├── README.md
├── report/ TSP_DP_Report.docx, TSP_DP_Report.pdf
├── src/   tsp_dp.py, make_diagram.py, make_animation.py
└── docs/  prompt.txt, dp_transitions.png, dp_animation.gif
```
