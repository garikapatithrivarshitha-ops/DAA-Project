"""Held-Karp dynamic programming for TSP (4-city example) with a transition trace."""
from itertools import combinations

DIST = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0],
]


def tsp_dp(dist, verbose=True):
    n = len(dist)
    g, parent = {}, {}
    for j in range(1, n):
        g[(frozenset([j]), j)] = dist[0][j]
        parent[(frozenset([j]), j)] = 0
    for size in range(2, n):
        for combo in combinations(range(1, n), size):
            S = frozenset(combo)
            for j in S:
                prev = S - {j}
                cost, k = min((g[(prev, k)] + dist[k][j], k) for k in prev)
                g[(S, j)] = cost
                parent[(S, j)] = k
                if verbose:
                    opts = ", ".join(f"via {m}: {g[(prev, m)]}+{dist[m][j]}={g[(prev, m)] + dist[m][j]}" for m in sorted(prev))
                    print(f"g({sorted(S)}, {j}) = min({opts}) = {cost}")
    full = frozenset(range(1, n))
    total, last = min((g[(full, j)] + dist[j][0], j) for j in full)
    tour, S, j = [0], full, last
    path = []
    while j != 0:
        path.append(j)
        S, j = S - {j}, parent[(S, j)]
    tour += path[::-1] + [0]
    return total, tour, g


if __name__ == "__main__":
    total, tour, _ = tsp_dp(DIST)
    print("\nOptimal cost:", total)
    print("Tour:", " -> ".join(map(str, tour)))
