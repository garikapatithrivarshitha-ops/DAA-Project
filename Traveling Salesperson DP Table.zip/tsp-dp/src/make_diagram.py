"""Generates docs/dp_transitions.png - layered DP state-transition graph."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

cols = {0: 0.6, 1: 2.4, 2: 4.6, 3: 6.8, 4: 9.0}
N = {  # name: (col, y, label, cost, optimal)
 "s": (0, 5, "City 0", "0", 1),
 "1": (1, 7, "{1}→1", "10", 1), "2": (1, 5, "{2}→2", "15", 0), "3": (1, 3, "{3}→3", "20", 0),
 "12a": (2, 8.5, "{1,2}→1", "50", 0), "12b": (2, 7.5, "{1,2}→2", "45", 0),
 "13a": (2, 6.5, "{1,3}→1", "45", 0), "13b": (2, 5.5, "{1,3}→3", "35", 1),
 "23a": (2, 3.5, "{2,3}→2", "50", 0), "23b": (2, 2.5, "{2,3}→3", "45", 0),
 "A": (3, 7.5, "{1,2,3}→1", "70", 0), "B": (3, 5.5, "{1,2,3}→2", "65", 1), "C": (3, 3.5, "{1,2,3}→3", "75", 0),
 "TA": (4, 7.5, "Tour 80", "70+10", 1), "TB": (4, 5.5, "Tour 80", "65+15", 1), "TC": (4, 3.5, "Tour 95", "75+20", 0),
}
# (src, dst, chosen_by_min, on_optimal_path)
E = [("s","1",1,1),("s","2",1,0),("s","3",1,0),
     ("2","12a",1,0),("1","12b",1,0),("3","13a",1,0),("1","13b",1,1),("3","23a",1,0),("2","23b",1,0),
     ("23a","A",0,0),("23b","A",1,0),("13a","B",0,0),("13b","B",1,1),("12a","C",1,0),("12b","C",1,0),
     ("A","TA",1,0),("B","TB",1,1),("C","TC",1,0)]
W, H = 1.5, 0.7
fig, ax = plt.subplots(figsize=(13, 6.5))
for a, b, chosen, opt in E:
    x1, y1 = cols[N[a][0]] + W/2, N[a][1]; x2, y2 = cols[N[b][0]] - W/2, N[b][1]
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(
        arrowstyle="->", color="#0F6E56" if opt else "#888780", lw=2.5 if opt else 1,
        ls="-" if chosen else "--", alpha=1 if (opt or chosen) else .6))
for k, (c, y, lab, cost, opt) in N.items():
    x = cols[c]
    ax.add_patch(FancyBboxPatch((x-W/2, y-H/2), W, H, boxstyle="round,pad=0.02,rounding_size=0.08",
                 fc="#E1F5EE" if opt else "#F1EFE8", ec="#0F6E56" if opt else "#5F5E5A", lw=1))
    ax.text(x, y+.12, lab, ha="center", va="center", fontsize=10, weight="bold", color="#085041" if opt else "#2C2C2A")
    ax.text(x, y-.16, "cost " + cost if "+" not in cost else cost, ha="center", va="center", fontsize=9, color="#0F6E56" if opt else "#444441")
for c, t in zip(range(5), ["Start", "Subset size 1", "Subset size 2", "Subset size 3", "Return to 0"]):
    ax.text(cols[c], 9.4, t, ha="center", fontsize=11)
ax.text(0.2, 1.3, "Node = {visited cities} → last city.  Teal path = 0→1→3→2→0 (cost 80).  Dashed = transition not chosen by min.", fontsize=10)
ax.set_xlim(-0.5, 10); ax.set_ylim(1, 10); ax.axis("off")
ax.set_title("Held-Karp DP state transitions for TSP with 4 cities", fontsize=13)
plt.tight_layout(); plt.savefig("docs/dp_transitions.png", dpi=150)
