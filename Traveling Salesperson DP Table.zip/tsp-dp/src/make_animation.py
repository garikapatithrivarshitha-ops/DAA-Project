"""Generates docs/dp_animation.gif - step-by-step Held-Karp DP fill for 4 cities."""
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from PIL import Image

cols = {0: 0.6, 1: 2.4, 2: 4.6, 3: 6.8, 4: 9.0}
N = {
 "s": (0, 5, "City 0", "0", 1, "Start at city 0 with cost 0"),
 "1": (1, 7, "{1}→1", "10", 1, "g({1},1) = d(0,1) = 10"),
 "2": (1, 5, "{2}→2", "15", 0, "g({2},2) = d(0,2) = 15"),
 "3": (1, 3, "{3}→3", "20", 0, "g({3},3) = d(0,3) = 20"),
 "12a": (2, 8.5, "{1,2}→1", "50", 0, "g({1,2},1) = g({2},2) + d(2,1) = 15 + 35 = 50"),
 "12b": (2, 7.5, "{1,2}→2", "45", 0, "g({1,2},2) = g({1},1) + d(1,2) = 10 + 35 = 45"),
 "13a": (2, 6.5, "{1,3}→1", "45", 0, "g({1,3},1) = g({3},3) + d(3,1) = 20 + 25 = 45"),
 "13b": (2, 5.5, "{1,3}→3", "35", 1, "g({1,3},3) = g({1},1) + d(1,3) = 10 + 25 = 35"),
 "23a": (2, 3.5, "{2,3}→2", "50", 0, "g({2,3},2) = g({3},3) + d(3,2) = 20 + 30 = 50"),
 "23b": (2, 2.5, "{2,3}→3", "45", 0, "g({2,3},3) = g({2},2) + d(2,3) = 15 + 30 = 45"),
 "A": (3, 7.5, "{1,2,3}→1", "70", 0, "g({1,2,3},1) = min(50+35, 45+25) = min(85, 70) = 70"),
 "B": (3, 5.5, "{1,2,3}→2", "65", 1, "g({1,2,3},2) = min(45+35, 35+30) = min(80, 65) = 65"),
 "C": (3, 3.5, "{1,2,3}→3", "75", 0, "g({1,2,3},3) = min(50+25, 45+30) = min(75, 75) = 75 (tie)"),
 "TA": (4, 7.5, "Tour 80", "70+10", 1, "Close tour via city 1: 70 + d(1,0) = 70 + 10 = 80"),
 "TB": (4, 5.5, "Tour 80", "65+15", 1, "Close tour via city 2: 65 + d(2,0) = 65 + 15 = 80"),
 "TC": (4, 3.5, "Tour 95", "75+20", 0, "Close tour via city 3: 75 + d(3,0) = 75 + 20 = 95"),
}
# src, dst, chosen by min, on optimal path
E = [("s","1",1,1),("s","2",1,0),("s","3",1,0),
     ("2","12a",1,0),("1","12b",1,0),("3","13a",1,0),("1","13b",1,1),("3","23a",1,0),("2","23b",1,0),
     ("23a","A",0,0),("23b","A",1,0),("13a","B",0,0),("13b","B",1,1),("12a","C",1,0),("12b","C",1,0),
     ("A","TA",1,0),("B","TB",1,1),("C","TC",1,0)]
order = ["s","1","2","3","12a","12b","13a","13b","23a","23b","A","B","C","TA","TB","TC"]
W, H = 1.5, 0.7
TEAL, AMB = ("#E1F5EE", "#0F6E56", "#085041"), ("#FAEEDA", "#854F0B", "#633806")
GRAY = ("#F1EFE8", "#5F5E5A", "#2C2C2A")

def frame(step, final=False):
    shown = order[:step]
    fig, ax = plt.subplots(figsize=(13, 6.8))
    for a, b, chosen, opt in E:
        if b not in shown: continue
        hl = final and opt
        x1, y1 = cols[N[a][0]] + W/2, N[a][1]; x2, y2 = cols[N[b][0]] - W/2, N[b][1]
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(
            arrowstyle="->", color="#0F6E56" if hl else "#888780", lw=3 if hl else 1,
            ls="-" if chosen else "--", alpha=1 if (hl or chosen) else .6))
    for k in shown:
        c, y, lab, cost, opt, _ = N[k]; x = cols[c]
        fc, ec, tc = TEAL if (final and opt) else (AMB if (k == shown[-1] and not final) else GRAY)
        ax.add_patch(FancyBboxPatch((x-W/2, y-H/2), W, H, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec, lw=1.5))
        ax.text(x, y+.12, lab, ha="center", va="center", fontsize=10, weight="bold", color=tc)
        ax.text(x, y-.16, cost if "+" in cost else "cost " + cost, ha="center", va="center", fontsize=9, color=tc)
    for c, t in zip(range(5), ["Start", "Subset size 1", "Subset size 2", "Subset size 3", "Return to 0"]):
        ax.text(cols[c], 9.5, t, ha="center", fontsize=11)
    cap = "Optimal tour: 0 → 1 → 3 → 2 → 0, total cost 80" if final else N[shown[-1]][5]
    ax.text(5, 1.0, cap, ha="center", fontsize=13, weight="bold",
            color="#085041" if final else "#633806")
    ax.text(5, 0.4, "Node = {visited cities} → last city.   Dashed arrow = transition not chosen by min.", ha="center", fontsize=9, color="#5F5E5A")
    ax.set_xlim(-0.5, 10); ax.set_ylim(0, 10.2); ax.axis("off")
    ax.set_title("Held-Karp DP for TSP with 4 cities", fontsize=13)
    buf = io.BytesIO(); plt.tight_layout(); plt.savefig(buf, format="png", dpi=80); plt.close(fig)
    buf.seek(0); return Image.open(buf).convert("P", palette=Image.ADAPTIVE)

frames = [frame(i) for i in range(1, len(order) + 1)] + [frame(len(order), True)] * 2
durations = [1400] * len(order) + [3000, 3000]
frames[0].save("docs/dp_animation.gif", save_all=True, append_images=frames[1:], duration=durations, loop=0)
frames[-1].convert("RGB").save("docs/_preview_last.png")
frames[9].convert("RGB").save("docs/_preview_mid.png")
print("frames:", len(frames))
