# N-Queens Backtracking - Pseudocode

```
SOLVE(row, cols[]):
    if row == N:
        record cols as a solution; return
    for c in 0..N-1:
        if SAFE(cols, row, c):          # no same column / diagonal
            cols[row] = c
            SOLVE(row + 1, cols)        # go deeper (valid branch)
        else:
            prune                       # invalid branch (red)

SAFE(cols, row, c):
    for r in 0..row-1:
        if cols[r] == c or |cols[r] - c| == row - r:
            return false
    return true
```

Complexity: O(N!) worst case time, O(N) recursion space.

## Explanation
Each tree node is a partial placement (digits = column of the queen in rows 1..k, e.g. `241` = row1 col2, row2 col4, row3 col1).
The algorithm tries every column in the current row. If it conflicts with an earlier queen (same column or diagonal), the node is drawn **red** and not expanded (pruned, backtrack). Safe nodes are **green** and expanded to the next row. Complete safe placements are **gold** solutions.

For N = 4: 60 nodes explored, 2 solutions: `2413` and `3142` (mirror images).
Pruning avoids the 4^4 = 256 leaves of the unpruned tree.
