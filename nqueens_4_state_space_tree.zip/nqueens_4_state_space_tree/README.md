# N-Queens (N=4) - State Space Tree Visualization

**Unit:** Backtracking | **Course:** DAA Macro Project

## Problem
Place N queens on an NxN board so that no two attack each other.

## Prompt used for visualization
> Visualize the state space tree for N = 4 queens, marking invalid branches in red.

## Output
![animation](output/nqueens_4_tree.gif)

Final frame: `output/nqueens_4_tree_final.png`

## Algorithm
See [docs/algorithm.md](docs/algorithm.md) (pseudocode, explanation, complexity).

## Legend
- Green: valid partial placement (expanded)
- Red: invalid placement, pruned (backtrack)
- Gold: complete solution

## Run
```bash
pip install matplotlib pillow
python src/nqueens_tree.py 4     # change N if desired
```

## Structure
```
src/      generator script
docs/     pseudocode, prompt
output/   GIF + PNG
```

## Result
2 solutions for N=4: [2,4,1,3] and [3,1,4,2]. Time O(N!), space O(N).
