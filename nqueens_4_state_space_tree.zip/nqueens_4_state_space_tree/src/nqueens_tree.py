"""N-Queens (N=4) state space tree animation. Invalid branches in red.
Usage: python nqueens_tree.py [N]   -> writes ../output/nqueens_N_tree.gif and _final.png
"""
import sys, os, io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image

N = int(sys.argv[1]) if len(sys.argv) > 1 else 4


def safe(cols, c):
    r = len(cols)
    return all(c != cc and abs(c - cc) != r - rr for rr, cc in enumerate(cols))


nodes = []       # each: id, parent, cols, status, depth, kids
root_kids = []


def solve(cols, parent):
    for c in range(N):
        ok = safe(cols, c)
        new = cols + [c]
        st = "invalid" if not ok else ("solution" if len(new) == N else "valid")
        nid = len(nodes)
        nodes.append(dict(id=nid, parent=parent, cols=new, status=st, depth=len(new), kids=[]))
        if parent is None:
            root_kids.append(nid)
        else:
            nodes[parent]["kids"].append(nid)
        if ok and len(new) < N:
            solve(new, nid)


solve([], None)

xpos, leaf = {}, [0]


def layout(nid):
    n = nodes[nid]
    if not n["kids"]:
        xpos[nid] = leaf[0]
        leaf[0] += 1
    else:
        for k in n["kids"]:
            layout(k)
        xs = [xpos[k] for k in n["kids"]]
        xpos[nid] = sum(xs) / len(xs)


for k in root_kids:
    layout(k)
rx = sum(xpos[k] for k in root_kids) / len(root_kids)
W = leaf[0]
COL = {"valid": "#2e9e5b", "invalid": "#d62828", "solution": "#f2b705"}


def board_ax(ax, cols, status):
    ax.set_xlim(0, N)
    ax.set_ylim(0, N)
    ax.set_aspect("equal")
    ax.axis("off")
    for r in range(N):
        for c in range(N):
            ax.add_patch(Rectangle((c, N - 1 - r), 1, 1, fc="#f0d9b5" if (r + c) % 2 == 0 else "#b58863", ec="k", lw=.5))
    for r, c in enumerate(cols):
        bad = (r == len(cols) - 1 and status == "invalid")
        ax.add_patch(plt.Circle((c + .5, N - 1 - r + .5), .32, fc="#d62828" if bad else "#222", ec="white", lw=1.5))
        ax.text(c + .5, N - 1 - r + .5, "Q", ha="center", va="center", fontsize=11, color="white", weight="bold")


def frame(i):
    shown = nodes[:i + 1]
    fig = plt.figure(figsize=(max(14, W * 0.55), 8), dpi=80)
    ax = fig.add_axes([0.01, 0.02, 0.98, 0.84])
    ax.axis("off")
    ax.set_xlim(-1, W)
    ax.set_ylim(-N - 0.6, 0.8)
    ax.text(rx, 0.0, "root", ha="center", va="center", fontsize=9, bbox=dict(boxstyle="round", fc="#ddd"), zorder=3)
    for n in shown:
        px = rx if n["parent"] is None else xpos[n["parent"]]
        py = 0 if n["parent"] is None else -nodes[n["parent"]]["depth"]
        ax.plot([px, xpos[n["id"]]], [py, -n["depth"]],
                color=COL["invalid"] if n["status"] == "invalid" else "#888", lw=1.6, zorder=1)
    for n in shown:
        cur = n["id"] == i
        label = "".join(str(c + 1) for c in n["cols"])
        ax.text(xpos[n["id"]], -n["depth"], label, ha="center", va="center", fontsize=8, color="white", weight="bold", zorder=3,
                bbox=dict(boxstyle="round,pad=0.3", fc=COL[n["status"]], ec="black" if cur else COL[n["status"]], lw=2.5 if cur else 0.5))
    for d in range(1, N + 1):
        ax.text(-0.9, -d, f"Row {d}", fontsize=9, va="center", color="#555")
    n = nodes[i]
    msg = {"invalid": "CONFLICT -> prune & backtrack", "valid": "safe -> go deeper", "solution": "SOLUTION FOUND"}[n["status"]]
    fig.suptitle(f"{N}-Queens State Space Tree | Step {i + 1}/{len(nodes)}: Q in row {n['depth']}, col {n['cols'][-1] + 1} -> {msg}",
                 fontsize=13, color=COL[n["status"]], weight="bold", y=0.97)
    ax.text(W - 0.5, 0.6, "valid", color=COL["valid"], ha="right", fontsize=11, weight="bold")
    ax.text(W - 0.5, 0.3, "invalid (pruned)", color=COL["invalid"], ha="right", fontsize=11, weight="bold")
    ax.text(W - 0.5, 0.0, "solution", color=COL["solution"], ha="right", fontsize=11, weight="bold")
    bax = fig.add_axes([0.01, 0.78, 0.11, 0.19])
    board_ax(bax, n["cols"], n["status"])
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    return Image.open(buf).convert("RGB")


out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output")
frames = [frame(i) for i in range(len(nodes))]
sols = [[c + 1 for c in s["cols"]] for s in nodes if s["status"] == "solution"]
print("nodes:", len(nodes), "solutions:", sols)
frames[-1].save(os.path.join(out, f"nqueens_{N}_tree_final.png"))
durs = [450] * len(frames)
for k, n in enumerate(nodes):
    if n["status"] == "solution":
        durs[k] = 1500
durs[-1] = 3500
frames[0].save(os.path.join(out, f"nqueens_{N}_tree.gif"), save_all=True, append_images=frames[1:],
               duration=durs, loop=0, optimize=True)
