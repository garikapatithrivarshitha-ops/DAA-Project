"""Draws the Merge Sort recursion tree (splits on top, merges mirrored below)."""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from merge_sort import merge_sort

DATA = [38, 27, 43, 3, 9, 82, 10, 55]
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "images", "merge_sort_recursion_tree.png")


def build(arr, depth=0, x0=0.0, x1=1.0, nodes=None, edges=None, parent=None):
    """Collect node positions for the split tree."""
    if nodes is None:
        nodes, edges = [], []
    idx = len(nodes)
    nodes.append({"arr": arr, "depth": depth, "x": (x0 + x1) / 2})
    if parent is not None:
        edges.append((parent, idx))
    if len(arr) > 1:
        mid = len(arr) // 2
        xm = (x0 + x1) / 2
        build(arr[:mid], depth + 1, x0, xm, nodes, edges, idx)
        build(arr[mid:], depth + 1, xm, x1, nodes, edges, idx)
    return nodes, edges


def box(ax, x, y, text, color, n_items):
    ax.text(x, y, text, ha="center", va="center", fontsize=9, fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.45", fc=color, ec="#333", lw=1.2), zorder=3)


def fmt(a):
    return "[" + ", ".join(map(str, a)) + "]"


def main():
    nodes, edges = build(DATA)
    max_d = max(n["depth"] for n in nodes)  # 3 for n = 8
    step = 1.7
    sy = lambda d: -d * step                          # divide rows (top -> bottom)
    my = lambda d: -(2 * max_d + 1 - d) * step        # merge rows (bottom -> top)

    fig, ax = plt.subplots(figsize=(16, 14))
    ax.set_xlim(-0.08, 1.04)
    ax.set_ylim(my(0) - 1.5, 1.6)
    ax.axis("off")
    ax.set_title("Merge Sort Recursion Tree  (n = 8)", fontsize=17, fontweight="bold")

    # Divide phase
    for p, c in edges:
        ax.annotate("", xy=(nodes[c]["x"], sy(nodes[c]["depth"]) + 0.3),
                    xytext=(nodes[p]["x"], sy(nodes[p]["depth"]) - 0.3),
                    arrowprops=dict(arrowstyle="->", color="#c0392b", lw=1.5))
    for n in nodes:
        box(ax, n["x"], sy(n["depth"]), fmt(n["arr"]), "#fadbd8", len(n["arr"]))

    # Conquer phase (verified against the real algorithm)
    for n in nodes:
        result = merge_sort(n["arr"])
        assert result == sorted(n["arr"])
        box(ax, n["x"], my(n["depth"]), fmt(result), "#d5f5e3", len(n["arr"]))
    for p, c in edges:
        ax.annotate("", xy=(nodes[p]["x"], my(nodes[p]["depth"]) + 0.3),
                    xytext=(nodes[c]["x"], my(nodes[c]["depth"]) - 0.3),
                    arrowprops=dict(arrowstyle="->", color="#1e8449", lw=1.5))

    sizes = [8, 4, 2, 1]
    for d in range(max_d + 1):
        ax.text(-0.08, sy(d), f"Level {d}\nsize {sizes[d]}", fontsize=9, va="center", color="#555")
        ax.text(-0.08, my(d), f"Level {d}\nsize {sizes[d]}", fontsize=9, va="center", color="#555")

    mid_y = (sy(max_d) + my(max_d)) / 2
    ax.text(0.5, mid_y, "Base case: single elements are already sorted",
            ha="center", va="center", fontsize=11, style="italic", color="#555")
    ax.text(0.5, 1.1, "DIVIDE  (split in half)", ha="center", fontsize=13,
            color="#c0392b", fontweight="bold")
    ax.text(0.5, my(0) - 1.0, "CONQUER / COMBINE  (merge sorted halves)", ha="center",
            fontsize=13, color="#1e8449", fontweight="bold")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    plt.savefig(OUT, dpi=150, bbox_inches="tight")
    print("Saved", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
