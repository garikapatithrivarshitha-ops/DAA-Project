"""Merge Sort implementation with step tracing (DAA Macro Project - Unit I)."""


def merge_sort(arr, depth=0, trace=None):
    """Sort arr using merge sort. If trace is a list, record every split and merge."""
    if trace is not None:
        trace.append(("split", depth, list(arr)))

    # Base case: 0 or 1 element is already sorted
    if len(arr) <= 1:
        return list(arr)

    mid = len(arr) // 2
    left = merge_sort(arr[:mid], depth + 1, trace)
    right = merge_sort(arr[mid:], depth + 1, trace)
    merged = merge(left, right)

    if trace is not None:
        trace.append(("merge", depth, merged))
    return merged


def merge(left, right):
    """Merge two sorted lists into one sorted list in O(n) time."""
    result, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result


if __name__ == "__main__":
    data = [38, 27, 43, 3, 9, 82, 10, 55]
    steps = []
    print("Input :", data)
    print("Output:", merge_sort(data, trace=steps))
    print("\nTrace:")
    for kind, depth, arr in steps:
        print("  " * depth + f"{kind:5} {arr}")
