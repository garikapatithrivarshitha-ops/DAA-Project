# Pseudocode: Merge Sort

```
MERGE-SORT(A, low, high)
    if low >= high                      // base case: 0 or 1 element
        return
    mid = floor((low + high) / 2)
    MERGE-SORT(A, low, mid)             // sort left half
    MERGE-SORT(A, mid + 1, high)        // sort right half
    MERGE(A, low, mid, high)            // combine

MERGE(A, low, mid, high)
    L = A[low .. mid]
    R = A[mid+1 .. high]
    i = 0, j = 0, k = low
    while i < length(L) and j < length(R)
        if L[i] <= R[j]
            A[k] = L[i];  i = i + 1
        else
            A[k] = R[j];  j = j + 1
        k = k + 1
    copy remaining elements of L (if any) into A
    copy remaining elements of R (if any) into A
```

## Complexity

Recurrence: `T(n) = 2T(n/2) + O(n)`, with `T(1) = O(1)`.

| Case    | Time          | Space |
|---------|---------------|-------|
| Best    | O(n log n)    | O(n)  |
| Average | O(n log n)    | O(n)  |
| Worst   | O(n log n)    | O(n)  |

Merge sort is stable.
