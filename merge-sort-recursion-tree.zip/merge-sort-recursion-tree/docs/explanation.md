# Explanation

## Algorithm logic
Merge Sort uses **divide and conquer**:

1. **Divide:** split the array into two halves.
2. **Conquer:** recursively sort each half. A single element is already sorted (the base case).
3. **Combine:** merge the two sorted halves into one sorted array by repeatedly taking the smaller front element.

## Reading the visualization
- **Red top half (divide):** the array of 8 splits into 4+4, then 2+2+2+2, then 8 single elements. That is `log2(8) = 3` levels of splitting.
- **Green bottom half (combine):** the sorted pieces merge back up, 1 -> 2 -> 4 -> 8, giving `[3, 9, 10, 27, 38, 43, 55, 82]`.
- Each level does about `n` work in total (every element is touched once per level). With `log n` levels, the total is **O(n log n)**.

| Level | Subproblems | Size each | Work at this level |
|-------|-------------|-----------|--------------------|
| 0     | 1           | 8         | 8                  |
| 1     | 2           | 4         | 8                  |
| 2     | 4           | 2         | 8                  |
| 3     | 8           | 1         | 8                  |

Total work = 8 x (levels) -> `n log n`.
