# Recursion Tree for Merge Sort

**DAA Macro Project | Unit I: Algorithm Analysis | Project 2**

## Objective
Visualize how Merge Sort recursively splits an array of 8 elements and merges the pieces back together, and relate the tree to the `O(n log n)` time complexity.

## Repository Structure
```
merge-sort-recursion-tree/
├── README.md
├── src/
│   ├── merge_sort.py        # Merge sort implementation with trace output
│   └── generate_tree.py     # Script that draws the recursion tree
├── images/
│   └── merge_sort_recursion_tree.png
└── docs/
    ├── pseudocode.md
    ├── prompt_used.md
    └── explanation.md
```

## Visualization
![Merge Sort Recursion Tree](images/merge_sort_recursion_tree.png)

## How to Run
```bash
pip install matplotlib
cd src
python merge_sort.py        # prints the sorted array and a split/merge trace
python generate_tree.py     # regenerates ../images/merge_sort_recursion_tree.png
```

## Algorithm Summary
Divide the array in half, sort each half recursively, then merge the sorted halves.
Recurrence: `T(n) = 2T(n/2) + O(n)` -> **O(n log n)** in best, average and worst cases; space O(n).

See [`docs/pseudocode.md`](docs/pseudocode.md), [`docs/explanation.md`](docs/explanation.md) and [`docs/prompt_used.md`](docs/prompt_used.md).

## Author
Name: _<your name>_ &nbsp;|&nbsp; Group: _<group no.>_ &nbsp;|&nbsp; Roll No: _<roll no.>_
