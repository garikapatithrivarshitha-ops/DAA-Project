# Short Project Explanation

## Algorithm Logic
The 0/1 Knapsack problem asks us to select or reject each item while maximizing profit without exceeding the capacity. Branch and Bound represents these decisions as a state-space tree.

For every node, an upper bound estimates the maximum profit that could still be obtained from that node. The estimate can use a fractional part of an item even though the actual solution is 0/1; this makes the bound optimistic.

The algorithm keeps `bestProfit`, the best feasible solution found so far. If `bound <= bestProfit`, that node cannot lead to a better answer, so its branch is pruned.

## Visualization Logic
The interactive simulator allows the user to enter values. It then builds the tree according to the algorithm. Nodes display weight, profit, and bound. The best profit changes as better feasible solutions are discovered. Unpromising or overweight branches are visually marked.

## Result for the Default Example
Capacity = 10

Selected items = I1, I2, I3

Total weight = 10

Maximum profit = 160
