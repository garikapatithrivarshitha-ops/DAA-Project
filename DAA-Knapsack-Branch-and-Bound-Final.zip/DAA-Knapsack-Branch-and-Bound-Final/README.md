# 0/1 Knapsack Using Branch and Bound

## DAA Macro Project — Unit V

This project demonstrates **bounding and pruning in the 0/1 Knapsack problem using Branch and Bound**.

### Default Example
Capacity = **10**

| Item | Weight | Profit | Profit/Weight |
|---|---:|---:|---:|
| I1 | 2 | 40 | 20.00 |
| I2 | 3 | 50 | 16.67 |
| I3 | 5 | 70 | 14.00 |
| I4 | 6 | 80 | 13.33 |

Optimal selection: **I1, I2, I3**

Maximum profit: **160**

## Main Features
- Java Branch and Bound implementation
- Complete algorithm and pseudocode
- Exact node-bound calculations
- Static search-tree diagram
- **Interactive visualization where users enter their own values**
- Step-by-step Include/Exclude branching
- Dynamic Best Profit
- Dynamic upper bounds
- Visual pruning
- Activity log
- Slow / Normal / Fast animation speeds
- AI visualization prompt
- Presentation PPT

## Interactive Visualization
Open:

`index.html`

Then enter:
1. Knapsack capacity
2. Item weights
3. Item profits

Click **Start Simulation**.

The tree is built according to the Branch and Bound algorithm. It is deterministic, not random.

### Color Meaning
- **Blue** — active/search node
- **Green** — current best solution
- **Red** — pruned branch
- **Amber** — invalid/overweight branch

## Files

```text
DAA-Knapsack-Branch-and-Bound-Final/
├── README.md
├── index.html
├── algorithm.txt
├── pseudocode.txt
├── exact_node_calculations.txt
├── ai_visualization_prompt.txt
├── project_explanation.md
├── knapsack_branch_bound.java
├── knapsack_tree.png
├── Knapsack_Branch_and_Bound.pptx
└── animation.html
```

## Java Execution

```bash
javac knapsack_branch_bound.java
java knapsack_branch_bound
```

## Complexity
Worst-case time complexity: **O(2^n)**.

Branch and Bound can explore substantially fewer nodes because unpromising branches are pruned.

## Conclusion
Branch and Bound improves the practical search process by calculating an optimistic upper bound and avoiding branches that cannot improve the best known feasible solution.
