import java.util.*;

public class knapsack_branch_bound {
    static class Item {
        int weight, profit;
        double ratio;
        Item(int weight, int profit) {
            this.weight = weight;
            this.profit = profit;
            this.ratio = (double) profit / weight;
        }
    }

    static class Node {
        int level, weight, profit;
        double bound;
        Node(int level, int weight, int profit, double bound) {
            this.level = level;
            this.weight = weight;
            this.profit = profit;
            this.bound = bound;
        }
    }

    static int capacity;
    static Item[] items;

    static double bound(Node u) {
        if (u.weight >= capacity) return u.profit;

        double profitBound = u.profit;
        int totalWeight = u.weight;
        int j = u.level;

        while (j < items.length && totalWeight + items[j].weight <= capacity) {
            totalWeight += items[j].weight;
            profitBound += items[j].profit;
            j++;
        }

        if (j < items.length) {
            int remaining = capacity - totalWeight;
            profitBound += remaining * items[j].ratio;
        }
        return profitBound;
    }

    static int solve() {
        PriorityQueue<Node> pq =
            new PriorityQueue<>((a,b) -> Double.compare(b.bound,a.bound));

        Node root = new Node(0,0,0,0);
        root.bound = bound(root);
        pq.add(root);

        int bestProfit = 0;

        while (!pq.isEmpty()) {
            Node u = pq.poll();

            if (u.bound <= bestProfit || u.level >= items.length)
                continue;

            Item item = items[u.level];

            Node include = new Node(
                u.level + 1,
                u.weight + item.weight,
                u.profit + item.profit,
                0
            );

            if (include.weight <= capacity) {
                if (include.profit > bestProfit)
                    bestProfit = include.profit;

                include.bound = bound(include);

                if (include.bound > bestProfit)
                    pq.add(include);
            }

            Node exclude = new Node(
                u.level + 1,
                u.weight,
                u.profit,
                0
            );

            exclude.bound = bound(exclude);

            if (exclude.bound > bestProfit)
                pq.add(exclude);
        }

        return bestProfit;
    }

    public static void main(String[] args) {
        capacity = 10;

        items = new Item[] {
            new Item(2,40),
            new Item(3,50),
            new Item(5,70),
            new Item(6,80)
        };

        Arrays.sort(items, (a,b) -> Double.compare(b.ratio,a.ratio));

        System.out.println("0/1 Knapsack using Branch and Bound");
        System.out.println("Maximum Profit = " + solve());
    }
}
